#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKUP_ROOT="$WORKSPACE_ROOT/.backup"
PACKAGE_VERSION_FILE="$WORKSPACE_ROOT/PACKAGE-VERSION.yaml"
RUNTIME_ROOTS=(".gwc" ".task-me" ".ua" ".bmad")

usage() {
  cat <<'EOF'
Usage:
  bash scripts/rollback.sh <timestamp>
EOF
}

if [[ $# -lt 1 ]]; then
  usage
  exit 2
fi

TIMESTAMP="$1"
BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"

if [[ ! -d "$BACKUP_DIR" ]]; then
  echo "ERROR: backup not found: $BACKUP_DIR" >&2
  exit 1
fi

echo "Restoring PACKAGE-VERSION.yaml from backup"
cp "$BACKUP_DIR/installed-PACKAGE-VERSION.yaml" "$PACKAGE_VERSION_FILE"

echo "Restoring runtime roots from backup"
for root in "${RUNTIME_ROOTS[@]}"; do
  if [[ -d "$BACKUP_DIR/$root" ]]; then
    rm -rf "$WORKSPACE_ROOT/$root"
    cp -a "$BACKUP_DIR/$root" "$WORKSPACE_ROOT/$root"
    echo "RESTORED: $root"
  fi
done

echo "Rollback complete. Run: dw doctor all"
