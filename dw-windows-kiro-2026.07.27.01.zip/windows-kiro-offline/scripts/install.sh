#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
INSTALL_MARKER="# generated-by: DW-SuperApps Windows offline installer"
PROFILE_START="# >>> DW SuperApps CLI >>>"
PROFILE_END="# <<< DW SuperApps CLI <<<"

usage() {
  cat <<'EOF'
Usage:
  bash scripts/install.sh [--target /path/to/workspace] [--profile bash|zsh|none] [--force] [--init]
EOF
}

TARGET="$WORKSPACE_ROOT"
PROFILE_MODE="bash"
FORCE=0
RUN_INIT=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target)
      [[ $# -ge 2 ]] || { echo "ERROR: --target requires a value" >&2; exit 2; }
      TARGET="$(cd "$2" && pwd)"
      shift 2
      ;;
    --profile)
      [[ $# -ge 2 ]] || { echo "ERROR: --profile requires a value" >&2; exit 2; }
      PROFILE_MODE="$2"
      shift 2
      ;;
    --force) FORCE=1; shift ;;
    --init) RUN_INIT=1; shift ;;
    -h|--help|help) usage; exit 0 ;;
    *) echo "ERROR: unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done

case "$PROFILE_MODE" in
  bash|zsh|none) ;;
  *) echo "ERROR: unsupported profile: $PROFILE_MODE" >&2; exit 2 ;;
esac

if [[ ! -d "$TARGET" ]]; then
  echo "ERROR: target directory does not exist: $TARGET" >&2
  exit 1
fi

BIN_DIR="$TARGET/bin"
LAUNCHER="$BIN_DIR/dw"

install_launcher() {
  mkdir -p "$BIN_DIR"
  chmod +x "$SCRIPT_DIR/../bin/dw"
  if [[ -e "$LAUNCHER" || -L "$LAUNCHER" ]]; then
    if [[ -f "$LAUNCHER" ]] && grep -Fq "$INSTALL_MARKER" "$LAUNCHER"; then
      :
    elif [[ "$FORCE" -eq 1 ]]; then
      rm -rf "$LAUNCHER"
    else
      echo "ERROR: refusing to replace unmanaged $LAUNCHER; use --force" >&2
      exit 1
    fi
  fi
  {
    echo '#!/usr/bin/env bash'
    echo "$INSTALL_MARKER"
    printf 'exec %q "$@"\n' "$TARGET/bin/dw"
  } > "$LAUNCHER"
  chmod +x "$LAUNCHER"
  echo "INSTALLED: $LAUNCHER"
}

write_profile_block() {
  local profile="$1"
  local tmp
  mkdir -p "$(dirname "$profile")"
  touch "$profile"
  tmp="$(mktemp "${profile}.dw.XXXXXX")"
  awk -v start="$PROFILE_START" -v end="$PROFILE_END" '
    $0 == start { skip = 1; next }
    $0 == end { skip = 0; next }
    !skip { print }
  ' "$profile" > "$tmp"
  {
    cat "$tmp"
    printf '\n%s\n' "$PROFILE_START"
    printf '%s\n' "export PATH=\"$TARGET/bin:\$PATH\""
    printf '%s\n' "$PROFILE_END"
  } > "$profile"
  rm -f "$tmp"
  echo "PROFILE: $profile"
}

remove_profile_block() {
  local profile="$1"
  local tmp
  [[ -f "$profile" ]] || return 0
  tmp="$(mktemp "${profile}.dw.XXXXXX")"
  awk -v start="$PROFILE_START" -v end="$PROFILE_END" '
    $0 == start { skip = 1; next }
    $0 == end { skip = 0; next }
    !skip { print }
  ' "$profile" > "$tmp"
  mv "$tmp" "$profile"
  echo "PROFILE CLEAN: $profile"
}

install_launcher

case "$PROFILE_MODE" in
  bash)
    write_profile_block "$HOME/.bashrc"
    ;;
  zsh)
    write_profile_block "$HOME/.zshrc"
    ;;
  none)
    echo "No shell profile modified. Ensure $TARGET/bin is on PATH."
    ;;
esac

echo
echo "DW CLI installed to $TARGET"
echo "Verify with: $TARGET/bin/dw --version"

if [[ "$RUN_INIT" -eq 1 ]]; then
  echo
  "$TARGET/bin/dw" init all --skip-deps
fi
