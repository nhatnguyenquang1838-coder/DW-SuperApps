#!/usr/bin/env bash
set -euo pipefail

WORKSPACE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "=== DW Offline Doctor ==="
echo

if [[ -x "$WORKSPACE_ROOT/bin/dw" ]]; then
  echo "[1/3] CLI launcher: OK"
else
  echo "[1/3] CLI launcher: MISSING" >&2
  exit 1
fi

if [[ -f "$WORKSPACE_ROOT/PACKAGE-VERSION.yaml" ]]; then
  echo "[2/3] Package manifest: OK"
else
  echo "[2/3] Package manifest: MISSING" >&2
  exit 1
fi

echo "[3/3] Running dw doctor all..."
"$WORKSPACE_ROOT/bin/dw" doctor all
