#!/usr/bin/env bash
set -euo pipefail

WORKSPACE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MIGRATION_FILE="$WORKSPACE_ROOT/.migration-applied"

usage() {
  cat <<'EOF'
Usage:
  bash scripts/migrate-runtime.sh [--check] [--force]
EOF
}

CHECK_ONLY=0
FORCE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --check) CHECK_ONLY=1; shift ;;
    --force) FORCE=1; shift ;;
    -h|--help|help) usage; exit 0 ;;
    *) echo "ERROR: unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done

if [[ -f "$MIGRATION_FILE" && "$FORCE" -ne 1 ]]; then
  echo "Runtime migrations already applied."
  if [[ "$CHECK_ONLY" -eq 1 ]]; then
    exit 0
  else
    exit 0
  fi
fi

if [[ "$CHECK_ONLY" -eq 1 ]]; then
  echo "Migrations pending."
  exit 0
fi

echo "Applying idempotent runtime migrations..."

# Placeholder for future schema migrations.
# Each migration must be idempotent and append a marker line to $MIGRATION_FILE.

mkdir -p "$WORKSPACE_ROOT/.gwc" "$WORKSPACE_ROOT/.task-me" "$WORKSPACE_ROOT/.ua" "$WORKSPACE_ROOT/.bmad"

touch "$MIGRATION_FILE"
echo "Runtime migrations applied."
