#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKUP_ROOT="$WORKSPACE_ROOT/.backup"
PACKAGE_VERSION_FILE="$WORKSPACE_ROOT/PACKAGE-VERSION.yaml"
RUNTIME_ROOTS=(".gwc" ".task-me" ".ua" ".bmad")

usage() {
  cat <<'EOF'
Usage:
  bash scripts/update.sh <new-package.zip> [--delta]
EOF
}

NEW_PACKAGE=""
DELTA=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --delta) DELTA=1; shift ;;
    -h|--help|help) usage; exit 0 ;;
    *) NEW_PACKAGE="$1"; shift ;;
  esac
done

if [[ -z "$NEW_PACKAGE" ]]; then
  usage
  exit 2
fi

if [[ ! -f "$NEW_PACKAGE" ]]; then
  echo "ERROR: package not found: $NEW_PACKAGE" >&2
  exit 1
fi

if [[ ! -f "$PACKAGE_VERSION_FILE" ]]; then
  echo "ERROR: current installation missing PACKAGE-VERSION.yaml" >&2
  exit 1
fi

TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"

echo "Creating runtime backup at $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

for root in "${RUNTIME_ROOTS[@]}"; do
  if [[ -d "$WORKSPACE_ROOT/$root" ]]; then
    cp -a "$WORKSPACE_ROOT/$root" "$BACKUP_DIR/$root"
    echo "BACKED UP: $root"
  fi
done

cp "$PACKAGE_VERSION_FILE" "$BACKUP_DIR/installed-PACKAGE-VERSION.yaml"
echo "BACKED UP: PACKAGE-VERSION.yaml"

TMPDIR="$(mktemp -d)"
cleanup() {
  rm -rf "$TMPDIR"
}
trap cleanup EXIT

echo "Extracting new package to $TMPDIR"
unzip -q "$NEW_PACKAGE" -d "$TMPDIR"

NEW_VERSION_FILE="$TMPDIR/PACKAGE-VERSION.yaml"
if [[ ! -f "$NEW_VERSION_FILE" ]]; then
  echo "ERROR: new package missing PACKAGE-VERSION.yaml" >&2
  exit 1
fi

CURRENT_VERSION="$(grep -E '^package_version:' "$PACKAGE_VERSION_FILE" | head -n1 | awk '{print $2}')"
NEW_VERSION="$(grep -E '^package_version:' "$NEW_VERSION_FILE" | head -n1 | awk '{print $2}')"

echo "Current version: $CURRENT_VERSION"
echo "New version: $NEW_VERSION"

if [[ "$DELTA" -eq 1 ]]; then
  BASE_VERSION="$(grep -E '^base_version:' "$NEW_VERSION_FILE" | head -n1 | awk '{print $2}')"
  if [[ "$CURRENT_VERSION" != "$BASE_VERSION" ]]; then
    echo "ERROR: delta base_version ($BASE_VERSION) does not match installed version ($CURRENT_VERSION)" >&2
    exit 1
  fi
  echo "Applying delta update from $BASE_VERSION to $NEW_VERSION"
else
  echo "Applying full update from $CURRENT_VERSION to $NEW_VERSION"
fi

RUNTIME_EXCLUDE=""
for root in "${RUNTIME_ROOTS[@]}"; do
  RUNTIME_EXCLUDE="$RUNTIME_EXCLUDE -path '$TMPDIR/$root' -prune -o"
done

echo "Replacing workspace files"
cd "$TMPDIR"
find . $RUNTIME_EXCLUDE -type f -o -type d | tail -n +2 | while IFS= read -r item; do
  src="$TMPDIR/$item"
  dst="$WORKSPACE_ROOT/$item"
  if [[ -d "$src" ]]; then
    mkdir -p "$dst"
  else
    mkdir -p "$(dirname "$dst")"
    cp -f "$src" "$dst"
  fi
done

echo "Running post-update validation"
if "$WORKSPACE_ROOT/bin/dw" doctor all; then
  echo "UPDATE SUCCESSFUL: $NEW_VERSION"
else
  echo "UPDATE VALIDATION FAILED: rolling back"
  bash "$SCRIPT_DIR/rollback.sh" "$TIMESTAMP"
  exit 1
fi
