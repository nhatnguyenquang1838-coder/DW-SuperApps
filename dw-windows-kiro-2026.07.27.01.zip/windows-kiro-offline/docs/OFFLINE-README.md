# DW SuperApps — Windows Kiro Offline Installation

## Prerequisites

- Windows 10/11 with **Git Bash** (from Git for Windows) or **MSYS2** bash
- `python3` on PATH (Python 3.9+)
- `unzip` on PATH (included with Git Bash)
- No internet access required after ZIP extraction

## Quick Start

1. Extract `dw-windows-kiro-<version>.zip` to a path without spaces, e.g.:
   - `C:\dw-superapps\`
   - `/d/dw-superapps/`

2. Open Git Bash in the extracted folder and run:

   ```bash
   bash scripts/install.sh --target "$(pwd)" --profile bash --init
   ```

3. Verify installation:

   ```bash
   dw --version
   dw doctor all
   ```

## Update

```bash
# Full replacement
bash scripts/update.sh dw-windows-kiro-<new-version>.zip

# Delta update (requires matching base_version)
bash scripts/update.sh dw-windows-kiro-<new-version>.delta.zip --delta
```

## Rollback

```bash
bash scripts/rollback.sh <timestamp>
```

The timestamp is the backup directory name under `.backup/`, e.g. `20260101-120000`.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `python3: command not found` | Python not on PATH | Install Python and select "Add to PATH" |
| `Permission denied` on scripts | CRLF line endings | Run `sed -i 's/\r$//' scripts/*.sh` |
| Path contains spaces | Bash quoting issue | Re-extract to `C:\dw-superapps\` |
| `dw: command not found` | PATH not reloaded | Run `source ~/.bashrc` or reopen Git Bash |

## Notes

- All runtime data lives under `.gwc/`, `.task-me/`, `.ua/`, `.bmad/` inside the workspace.
- No GitHub sync, no PowerShell, no cmd.exe is used by any installer script.
