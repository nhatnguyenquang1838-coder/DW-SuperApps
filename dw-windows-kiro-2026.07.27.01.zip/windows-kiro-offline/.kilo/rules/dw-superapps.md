<!-- generated-by: dw host install -->

# DW SuperApps — kilo adapter

Read `AGENTS.md` and `workspace.yaml` before acting.

## Registered Powers

- `bmad` — store `.dw/powers/bmad`; entrypoint `.dw/powers/bmad/distribution/skills/bmad`; resolution `workspace-store`; runtime `.bmad/`.
- `gwc` — store `.dw/powers/gwc`; entrypoint `.dw/powers/gwc/skills/gwc-g0`; resolution `workspace-store`; runtime `.gwc/`.
- `task-me` — store `.dw/powers/task-me`; entrypoint `.dw/powers/task-me/.kiro/skills/implementation-task-architect`; resolution `workspace-store`; runtime `.task-me/`.
- `ua` — store `.dw/powers/ua`; entrypoint `.dw/powers/ua/understand-anything-plugin/skills/understand`; resolution `workspace-store`; runtime `.ua/`.

## Routing

1. Resolve the target system from `workspace.yaml`.
2. Load Power code from the workspace distribution store first.
3. Use source submodules only as an explicit compatibility fallback.
4. Keep runtime and project configuration inside the selected system repository.
5. Keep packages, inbox, history, bindings, router, and all host adapters in DW-SuperApps.
6. Never install Power skill payloads into a registered system.

## Orchestration for rental-home

- Primary: `gwc`
- Workers: `task-me`, `bmad`, `ua`
- Delegation hooks:
  - Gate `g1` → `task-me` for intents task-decomposition, validation-planning; feed into `g1-options`
  - Gate `g1` → `bmad` for intents architecture-design, data-modeling; feed into `g1-options`
  - Gate `g1` → `ua` for intents dependency-mapping, impact-analysis; feed into `g1-preflight`

Use `dw orchestrator prompt --system rental-home --task "<task>"` for composed prompts.

Generate a host-neutral prompt:

`dw power prompt <power> --system <system> --task "<task>"`
