# MIGRATION-DESIGN

## D-1. Package Architecture

### D-1.1 Layout
```
dw-windows-kiro-<version>.zip
├── PACKAGE-VERSION.yaml
├── bin/
│   └── dw
├── scripts/
│   ├── install.sh
│   ├── update.sh
│   ├── rollback.sh
│   ├── doctor.sh
│   └── migrate-runtime.sh
├── hosts/
│   └── kiro/
│       ├── skills/
│       │   ├── bmad/SKILL.md
│       │   ├── gwc/SKILL.md
│       │   ├── task-me/SKILL.md
│       │   └── ua/SKILL.md
│       └── steering.md
├── packages/
│   └── powers/
│       ├── gwc/
│       ├── task-me/
│       ├── bmad/
│       └── ua/
├── .dw/
│   └── powers/
│       ├── gwc/
│       ├── task-me/
│       ├── bmad/
│       └── ua/
├── .kilo/
│   └── rules/
│       └── dw-superapps.md
├── workspace.yaml
└── docs/
    └── OFFLINE-README.md
```

### D-1.2 Invariants
- **No symlinks**: All files are regular files or directories.
- **No `.git/`**: Submodule pointers and git metadata are stripped.
- **No host adapters other than Kiro**: `hosts/` contains only `kiro/`.
- **Runtime roots excluded from updates**: `update.sh` prunes `.gwc/`, `.task-me/`, `.ua/`, `.bmad/` during extraction.

## D-2. Bootstrap Sequence

1. Extract ZIP to target path.
2. Run `bash scripts/install.sh --target <path> --profile bash --init`.
3. `install.sh` creates `bin/dw` launcher, appends PATH block to `~/.bashrc`, and runs `dw init all --skip-deps`.
4. `dw init all --skip-deps` creates empty runtime roots without fetching anything.
5. `dw doctor all` validates READY/PARTIAL/BLOCKED status.

## D-3. Update Protocol

### D-3.1 Full Replacement
- Each release is a complete ZIP named `dw-windows-kiro-<version>.zip`.
- `PACKAGE-VERSION.yaml` is authoritative.
- `update.sh` validates current version, backs up runtime, extracts new package, runs `doctor all`, and auto-rolls back on FAILED.

### D-3.2 Delta (Optional)
- Delta ZIP contains only changed files.
- `PACKAGE-VERSION.yaml` inside delta declares `base_version`.
- `update.sh --delta` checks `base_version == current package_version` before applying.

## D-4. Backward Compatibility Layer

### D-4.1 Runtime Isolation
- Runtime roots are version-agnostic directories inside the workspace.
- Power distributions may read old runtime data but must not delete or overwrite it during updates.

### D-4.2 Version Tolerance
- Each Power `MANIFEST.json` may declare `min_workspace_version`.
- `doctor all` compares installed workspace version against Power requirements.
- `PARTIAL` = ahead of requirement, `BLOCKED` = behind, `READY` = match.

### D-4.3 Schema Migration
- `migrate-runtime.sh` is idempotent.
- Each migration appends a marker to `.migration-applied`.
- No migration runs during delta update unless `PACKAGE-VERSION.yaml` declares `runtime_migrations: true`.

## D-5. Windows Bash Constraints

- All scripts use `#!/usr/bin/env bash`.
- No `cmd.exe /c` or `powershell -Command` invocations.
- Paths are quoted with `%q` in launcher and `"$VAR"` in scripts.
- Installer rejects target paths containing spaces.
